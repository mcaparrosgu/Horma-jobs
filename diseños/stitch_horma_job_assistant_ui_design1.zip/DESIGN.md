---
name: Calm Talent Platform
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#45474c'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#75777d'
  outline-variant: '#c5c6cd'
  surface-tint: '#545f73'
  primary: '#091426'
  on-primary: '#ffffff'
  primary-container: '#1e293b'
  on-primary-container: '#8590a6'
  inverse-primary: '#bcc7de'
  secondary: '#006c4a'
  on-secondary: '#ffffff'
  secondary-container: '#82f5c1'
  on-secondary-container: '#00714e'
  tertiary: '#070056'
  on-tertiary: '#ffffff'
  tertiary-container: '#130091'
  on-tertiary-container: '#8182ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e3fb'
  primary-fixed-dim: '#bcc7de'
  on-primary-fixed: '#111c2d'
  on-primary-fixed-variant: '#3c475a'
  secondary-fixed: '#85f8c4'
  secondary-fixed-dim: '#68dba9'
  on-secondary-fixed: '#002114'
  on-secondary-fixed-variant: '#005137'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c2c1ff'
  on-tertiary-fixed: '#0b006b'
  on-tertiary-fixed-variant: '#2e24cd'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
  canvas-bg: '#FAFAFA'
  surface-card: '#FFFFFF'
  surface-subtle: '#F8F9FA'
  border-hairline: '#F1F5F9'
  border-default: '#E2E8F0'
  text-obsidian: '#0F172A'
  text-muted: '#64748B'
  emerald-accent: '#059669'
  emerald-subtle: '#ECFDF5'
  amber-alert: '#D97706'
  amber-subtle: '#FFFBEB'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
  label-md:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
This design system defines an intentional, calm, and high-transparency job search and recruitment interface. Inspired by modern talent discovery ecosystems like Cord, Welcome to the Jungle, and Wellfound, the visual identity rejects high-pressure notification tropes, excessive banners, and sensory clutter.

The aesthetic marries **Minimalism** with **Modern Craft**:
- **Canvas:** Generous warm off-white and pure white surfaces that allow listings and profiles to breathe.
- **Micro-detail:** Delicate hairline micro-borders, refined typography hierarchies, and disciplined spacing.
- **Tone:** Authoritative, transparent, serene, and modern. Designed to treat engineering, product, and executive candidates with agency and respect.

## Colors
The color architecture establishes immediate cognitive hierarchy through high tonal discipline:

- **Primary (`#1E293B`):** Deep slate-navy anchors primary interactive elements (active buttons, primary headings, core actions), lending executive poise without the harshness of pure black.
- **Secondary (`#059669`):** A measured forest emerald dedicated to high signal metrics—match scores, verified salary bands, direct-to-founder indicators, and active status tags.
- **Tertiary (`#3E38DA`):** Deep indigo-cobalt used sparingly for specialized candidate links, application tracking highlights, and platform utility accents.
- **Neutral (`#64748B`):** Slate-gray calibrated for metadata, secondary supporting labels, and subheadings.
- **Canvas & Surface:** Built on an intentional separation between `#FAFAFA` (canvas background), `#FFFFFF` (card components), and `#F8F9FA` (hover fills, tag pills, filters).

## Typography
The system pairs **Plus Jakarta Sans** for headlines and titles with **Inter** for dense metadata and narrative descriptions.

- **Headlines:** Set in Plus Jakarta Sans with subtle negative letter-spacing for a modern, architectural feel.
- **Data & Body:** Inter delivers optimal legibility across salary ranges, technical skill lists, and hiring manager intros.
- **Micro-Labels (`label-sm`):** Rendered in uppercase with generous tracking (`0.04em`) when applied to company tags, stage badges, and remote status tags.

## Layout & Spacing
A 12-column responsive fluid grid governs the viewports, maxing out at `1280px` for optimal reading scanability.

- **Desktop (≥ 1024px):** 12 columns, `1.5rem` gutters, `3rem` canvas margins. Job search views utilize a split view (40% search and filters, 60% persistent detail card) or a clean single-column centered feed (`760px` max content width).
- **Tablet (768px – 1023px):** 8 columns, `1.25rem` gutters, `2rem` margins. Filters collapse into a high-utility horizontal drawer.
- **Mobile (< 768px):** 4 columns, `1rem` gutters, `1rem` edge margin. Cards take full column width with compact vertical gaps.

## Elevation & Depth
Depth relies on flat micro-structural definition instead of heavy dropshadows:

- **Border Hierarchy:** Primary separation comes from hairline outlines (`1px solid #E2E8F0` or `#F1F5F9`).
- **Cards & Surfaces:** Elevated cards use a double-layer diffuse shadow: `0 1px 2px 0 rgba(15, 23, 42, 0.04), 0 4px 12px -2px rgba(15, 23, 42, 0.03)`. Hover states raise the card subtly with `0 6px 20px -4px rgba(15, 23, 42, 0.08)`.
- **Modals & Overlays:** Soft, diffused elevation with `0 20px 40px -12px rgba(15, 23, 42, 0.12)`, backed by an off-white translucent frosted backdrop (`rgba(250, 250, 250, 0.8)` with `backdrop-filter: blur(8px)`).

## Shapes
The design system follows a `Rounded` (Level 2) geometry:
- Default interactive components, inputs, and list items have `0.5rem` (8px) corners.
- Cards, modal containers, and floating panels use `rounded-lg` (`1rem` / 16px).
- Status tags, salary badges, and match indicators utilize pill caps (`rounded-full` / `9999px`) to contrast cleanly against rectangular structural modules.

## Components

### Buttons
- **Primary:** Background `#1E293B`, text `#FFFFFF`, radius `0.5rem`, padding `0.625rem 1.25rem`. Hover shifts to `#0F172A` with gentle scale transition.
- **Secondary / Ghost:** Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`. Hover transitions background to `#F8F9FA`.
- **Match / Verified Action:** Background `#059669`, text `#FFFFFF`. Reserved for direct applications and verified talent introductions.

### Cards (Job Listings & Candidate Profiles)
- Background `#FFFFFF`, micro-border `1px solid #E2E8F0`, corner radius `1rem`, padding `1.5rem`.
- Internal sections are separated by light dividers (`#F1F5F9`). Top row features the company avatar, role title, and match badge. The bottom row clusters metadata (location, salary range, work style tags).

### Badges & Chips
- **Match Score:** Background `#ECFDF5`, text `#059669`, border `1px solid rgba(5, 150, 105, 0.2)`, pill-shaped (`9999px`), bold micro-typography (`label-sm`).
- **Tag / Filter Chip:** Background `#F8F9FA`, text `#475569`, border `1px solid #E2E8F0`, radius `0.5rem`, padding `0.25rem 0.625rem`. Hover background `#F1F5F9`.

### Input Fields & Search Bars
- Background `#FFFFFF`, border `1px solid #E2E8F0`, text `#0F172A`, placeholder `#94A3B8`. Focus state applies a subtle `#1E293B` ring (`0 0 0 1px #1E293B`) without aggressive glow. Height is calibrated to `44px` for touch and desktop ease.

### Selection Controls (Checkboxes & Radios)
- Unchecked: Border `1.5px solid #CBD5E1`, background `#FFFFFF`.
- Checked: Background `#1E293B`, check icon `#FFFFFF`, border `#1E293B`. Checkboxes use `4px` corner radius; radios use full circles.